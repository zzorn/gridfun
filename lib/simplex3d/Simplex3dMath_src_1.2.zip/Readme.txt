Project documentation is available at:
http://www.simplex3d.org/project/documentation/


Runtime requirements:
  - Scala 2.9.0.final or higher.

Build requirements:
  - Ant 1.7.1 or higher.
  - SCALA_HOME set to Scala 2.9.0.final or higher.


To build the project:
  1) open a console,
  2) cd into the project directory,
  3) type: ant
